
<?php $__env->startSection('title', 'Edit Design'); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto py-12">
    <h2 class="text-2xl font-bold mb-6 text-white">Edit Design</h2>
    <form action="<?php echo e(route('admin.designs.update', $design->id)); ?>" method="POST" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label class="block text-gray-300 mb-1">Title</label>
            <input type="text" name="title" value="<?php echo e($design->title); ?>" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3" required>
        </div>
        <div>
            <label class="block text-gray-300 mb-1">Description</label>
            <textarea name="description" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3" required><?php echo e($design->description); ?></textarea>
        </div>
        <div>
            <label class="block text-gray-300 mb-1">Category</label>
            <input type="text" name="category" value="<?php echo e($design->category); ?>" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3" required>
        </div>
        <div>
            <label class="block text-gray-300 mb-1">Image URL</label>
            <input type="text" name="image_path" value="<?php echo e($design->image_path); ?>" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3">
        </div>
        <div class="flex justify-end gap-2">
            <a href="<?php echo e(route('admin.designs')); ?>" class="px-4 py-2 rounded-xl bg-zinc-700 text-gray-200">Cancel</a>
            <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 text-white font-semibold">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pesonal-web\resources\views/admin/designs-edit.blade.php ENDPATH**/ ?>