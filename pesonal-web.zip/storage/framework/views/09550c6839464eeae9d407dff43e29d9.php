
<?php $__env->startSection('title', isset($design) ? 'Edit Design' : 'Create Design'); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto py-12">
    <h2 class="text-2xl font-bold mb-6 text-white"><?php echo e(isset($design) ? 'Edit Design' : 'Add New Design'); ?></h2>
    <form action="<?php echo e(isset($design) ? route('admin.designs.update', $design->id) : route('admin.designs.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php if(isset($design)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <div>
            <label class="block text-gray-300 mb-1">Title</label>
            <input type="text" name="title" value="<?php echo e(old('title', $design->title ?? '')); ?>" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3" required>
        </div>
        <div>
            <label class="block text-gray-300 mb-1">Description</label>
            <textarea name="description" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3" required><?php echo e(old('description', $design->description ?? '')); ?></textarea>
        </div>
        <div>
            <label class="block text-gray-300 mb-1">Category</label>
            <input type="text" name="category" value="<?php echo e(old('category', $design->category ?? '')); ?>" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3" required>
        </div>
        <div>
            <label class="block text-gray-300 mb-1">Image</label>
            <?php if(isset($design) && $design->image_path): ?>
                <div class="mb-2">
                    <img src="<?php echo e($design->image_path); ?>" alt="Current Image" class="h-20 rounded-lg border border-zinc-700">
                </div>
            <?php endif; ?>
            <input type="file" name="image" accept="image/*" class="w-full rounded-xl bg-zinc-800/50 border border-zinc-700/50 text-white px-4 py-3">
            <?php if($errors->has('image')): ?>
                <div class="text-red-500 text-sm mt-1"><?php echo e($errors->first('image')); ?></div>
            <?php endif; ?>
        </div>
        <div class="flex justify-end gap-2">
            <a href="<?php echo e(route('admin.designs')); ?>" class="px-4 py-2 rounded-xl bg-zinc-700 text-gray-200">Cancel</a>
            <button type="submit" class="px-6 py-2 rounded-xl bg-blue-600 text-white font-semibold"><?php echo e(isset($design) ? 'Update' : 'Create'); ?></button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pesonal-web\resources\views/admin/designs-form.blade.php ENDPATH**/ ?>